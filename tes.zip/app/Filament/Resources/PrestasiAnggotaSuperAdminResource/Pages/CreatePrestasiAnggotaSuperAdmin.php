<?php

namespace App\Filament\Resources\PrestasiAnggotaSuperAdminResource\Pages;

use App\Filament\Resources\PrestasiAnggotaSuperAdminResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePrestasiAnggotaSuperAdmin extends CreateRecord
{
    protected static string $resource = PrestasiAnggotaSuperAdminResource::class;
}
