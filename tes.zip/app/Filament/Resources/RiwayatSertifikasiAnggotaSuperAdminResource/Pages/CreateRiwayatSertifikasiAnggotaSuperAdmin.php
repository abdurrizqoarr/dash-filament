<?php

namespace App\Filament\Resources\RiwayatSertifikasiAnggotaSuperAdminResource\Pages;

use App\Filament\Resources\RiwayatSertifikasiAnggotaSuperAdminResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateRiwayatSertifikasiAnggotaSuperAdmin extends CreateRecord
{
    protected static string $resource = RiwayatSertifikasiAnggotaSuperAdminResource::class;
}
