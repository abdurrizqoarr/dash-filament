<?php

namespace App\Filament\Admin\Resources\PrestasiAnggotaAdminResource\Pages;

use App\Filament\Admin\Resources\PrestasiAnggotaAdminResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePrestasiAnggotaAdmin extends CreateRecord
{
    protected static string $resource = PrestasiAnggotaAdminResource::class;
}
