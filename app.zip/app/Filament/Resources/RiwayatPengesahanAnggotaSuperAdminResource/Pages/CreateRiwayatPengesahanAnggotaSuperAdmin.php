<?php

namespace App\Filament\Resources\RiwayatPengesahanAnggotaSuperAdminResource\Pages;

use App\Filament\Resources\RiwayatPengesahanAnggotaSuperAdminResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateRiwayatPengesahanAnggotaSuperAdmin extends CreateRecord
{
    protected static string $resource = RiwayatPengesahanAnggotaSuperAdminResource::class;
}
