<?php

namespace App\Filament\Resources\ProfileAnggotaSuperAdminResource\Pages;

use App\Filament\Resources\ProfileAnggotaSuperAdminResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateProfileAnggotaSuperAdmin extends CreateRecord
{
    protected static string $resource = ProfileAnggotaSuperAdminResource::class;
}
