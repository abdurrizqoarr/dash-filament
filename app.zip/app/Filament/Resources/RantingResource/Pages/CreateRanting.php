<?php

namespace App\Filament\Resources\RantingResource\Pages;

use App\Filament\Resources\RantingResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateRanting extends CreateRecord
{
    protected static string $resource = RantingResource::class;
}
