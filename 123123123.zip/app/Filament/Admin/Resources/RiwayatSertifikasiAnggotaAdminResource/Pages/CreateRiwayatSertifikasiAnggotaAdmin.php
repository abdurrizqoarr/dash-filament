<?php

namespace App\Filament\Admin\Resources\RiwayatSertifikasiAnggotaAdminResource\Pages;

use App\Filament\Admin\Resources\RiwayatSertifikasiAnggotaAdminResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateRiwayatSertifikasiAnggotaAdmin extends CreateRecord
{
    protected static string $resource = RiwayatSertifikasiAnggotaAdminResource::class;
}
