<?php

namespace App\Filament\Resources\JabatanSuperAdminResource\Pages;

use App\Filament\Resources\JabatanSuperAdminResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateJabatanSuperAdmin extends CreateRecord
{
    protected static string $resource = JabatanSuperAdminResource::class;
}
