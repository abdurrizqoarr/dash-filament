<?php

namespace App\Filament\Resources\RiwayatPendidikanAnggotaSuperAdminResource\Pages;

use App\Filament\Resources\RiwayatPendidikanAnggotaSuperAdminResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateRiwayatPendidikanAnggotaSuperAdmin extends CreateRecord
{
    protected static string $resource = RiwayatPendidikanAnggotaSuperAdminResource::class;
}
