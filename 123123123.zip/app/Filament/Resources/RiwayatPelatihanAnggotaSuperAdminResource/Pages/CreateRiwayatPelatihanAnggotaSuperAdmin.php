<?php

namespace App\Filament\Resources\RiwayatPelatihanAnggotaSuperAdminResource\Pages;

use App\Filament\Resources\RiwayatPelatihanAnggotaSuperAdminResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateRiwayatPelatihanAnggotaSuperAdmin extends CreateRecord
{
    protected static string $resource = RiwayatPelatihanAnggotaSuperAdminResource::class;
}
